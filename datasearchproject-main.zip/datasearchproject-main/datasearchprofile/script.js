document.getElementById("abrir").onclick =()=>{ 

    document.getElementById("menu").style.left="0px";
}
     document.getElementById("fechar").onclick=()=>{     
         document.getElementById("menu").style.left="-200px";
     }